
#ifndef _globals_h
#define _globals_h
	#define APP_SIGNATURE "application/x-vnd.generic-BYdpDict"
	extern int AppReturnValue;
#endif
